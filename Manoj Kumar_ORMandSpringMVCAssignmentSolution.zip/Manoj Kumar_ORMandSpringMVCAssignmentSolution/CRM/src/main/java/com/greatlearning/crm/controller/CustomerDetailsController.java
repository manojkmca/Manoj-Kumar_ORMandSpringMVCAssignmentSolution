package com.greatlearning.crm.controller;

import java.util.List;

import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.crm.service.CustomerDetailsService;

import com.greatlearning.crm.entities.CustomerDetails;

/**
 * Customer Details Controller
 *
 */
@Controller
@RequestMapping("/customer")
public class CustomerDetailsController {
	
	@Autowired
	private CustomerDetailsService custDetailsService;
	
	@RequestMapping("/list")
	public String listCustomerDetails(Model model) {
		List<CustomerDetails> custDetails = custDetailsService.findAll();
		model.addAttribute("Customers", custDetails);
		return "list-details";
	}
	
	@RequestMapping("/delete")
	public String deleteCustomerDetails(@RequestParam("custId") int id) {
		custDetailsService.deleteById(id);
		return "redirect:/customer/list";
	}
	
	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		CustomerDetails custDetails = new CustomerDetails();
		theModel.addAttribute("Customers", custDetails);
		return "customerdetails-entry";
	}

	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("custId") int id, Model theModel) {
		CustomerDetails custDetails = custDetailsService.findById(id);
		theModel.addAttribute("Customers", custDetails);
		return "customerdetails-entry";
	}
	
	@PostMapping("/save")
	public String saveCustomerDetails(@RequestParam("id") int id, @RequestParam("firstname") String firstName,
			@RequestParam("lastname") String lastName, @RequestParam("email") String email) {
		CustomerDetails custDetails;
		if (id != 0) {
			custDetails = custDetailsService.findById(id);
			custDetails.setFirstName(firstName);
			custDetails.setLastName(lastName);
			custDetails.setEmail(email);
		} else {
			custDetails = new CustomerDetails(firstName, lastName, email);
		}
		custDetailsService.save(custDetails);
		return "redirect:/customer/list";

	}
}
